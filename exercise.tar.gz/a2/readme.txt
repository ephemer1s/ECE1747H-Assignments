Run sequential solution: ./solutions 0
Run parallel solution 1: ./solutions 1
Run parallel solution 2: ./solutions 2


